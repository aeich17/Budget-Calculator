/** Group Members: Ej Boakye, Adam Eichman, Michel Emborsky, Jake Ferner, Hunter Uebelacker
 * Date: 11/27/2022
 * Section: CSC 331 * Purpose: AreaController is the controller for the Area.fxml scene.
 * This scene includes buttons, textfields, Vbox, TableColumns, and a Label. addAreaAction and removeAreaAction
 * methods are used to manipulate different areas of the budget. The user can add a percentage area to teh budget,
 * example would be Building cost being 5% of the budget. Users can also remove different areas. These areas * will later be displayed on a pie chart. */

package com.example.budgetcalculator;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.text.NumberFormat;
import java.util.ArrayList;

public class AreaController {

    @FXML
    private Button Business;

    @FXML
    private Button Personal;

    @FXML
    private Button Settings;

    @FXML
    private TextField areaNameInput;

    @FXML
    private Button areaNext;

    @FXML
    private TableView<Area> allTable;

    @FXML
    private TableColumn<Area, String> areaTable;

    @FXML
    private TableColumn<Area, Integer> percentTable;

    @FXML
    private Label percentLabel;

    @FXML
    private Slider percentSlider;

    @FXML
    private Label percentLeft;

    @FXML
    private Button removeArea;

    @FXML
    private Button addArea;



    private static final NumberFormat percent = NumberFormat.getPercentInstance();

    private double areaPercentage = 0.00;
    private double percentLeftFinal = 1.00;

    public void initialize() {

            percentSlider.valueProperty().addListener((ov, oldValue, newValue) -> {  // changes slider number
                areaPercentage = (newValue.intValue() / 100.0);
                percentLabel.setText(percent.format(areaPercentage));
            });


        areaTable.setCellValueFactory(new PropertyValueFactory<Area, String>("areaName"));
        percentTable.setCellValueFactory(new PropertyValueFactory<Area, Integer>("percentage"));

    }

    double countPercent = 100;

    ArrayList<String> arrayAreas = new ArrayList<String>();  // creates an array for objects

    // Add
    @FXML
    void addAreaAction(ActionEvent event) {
        countPercent -= Math.round(areaPercentage * 100);       // Keeps track of the count percent that is shown for user


        if ((countPercent <= 100) & (countPercent >= 0)) {      // Checks for valid percent total
            Area area = new Area(areaNameInput.getText(), areaPercentage);      // creates new area object
            ObservableList<Area> areas = allTable.getItems();
            areas.add(area);
            allTable.setItems(areas);       // adds values to table
            percentLeftFinal = countPercent / 100;
            arrayAreas.add(String.valueOf(area));
            percentLeft.setText(percent.format(percentLeftFinal));      // updates percent left
            areaNameInput.clear();      // clears input
            percentSlider.setValue(percentSlider.getMin());     // resets slider
        }

        else {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);    // outputs a error if total % is over 100
            errorAlert.setHeaderText("User Error");
            errorAlert.setContentText("Total percentage must be no more than 100");
            errorAlert.showAndWait();
            countPercent += Math.round(areaPercentage * 100);
            percentSlider.setValue(percentSlider.getMin());         // resets slider

        }
    }

    @FXML
    void removeAreaAction(ActionEvent event) {
        Area tempArea = allTable.getSelectionModel().getSelectedItem();
        countPercent += (tempArea.getPercentage()) * 100;
        percentLeftFinal = countPercent / 100;
        percentLeft.setText(percent.format(percentLeftFinal));
        ObservableList<Area> chosenRow = allTable.getSelectionModel().getSelectedItems();
        ArrayList<Area> rowDelete = new ArrayList<>(chosenRow);
        arrayAreas.add(String.valueOf(chosenRow));  // Test
        rowDelete.forEach(row -> allTable.getItems().remove(row));      // removes selected item
    }


    public void changeSceneBtn3() throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("BackupPie.fxml"));
        Stage window = (Stage) areaNext.getScene().getWindow();
        window.setScene(new Scene(root));


    }
}



