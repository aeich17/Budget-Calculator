/** Group Members: Ej Boakye, Adam Eichman, Michel Emborsky, Jake Ferner, Hunter Uebelacker
 * Date: 11/27/2022
 * Section: CSC 331
 * Purpose: Menu is the class to hold user input variables.
**/


package com.example.budgetcalculator;

public class Menu {
    public double userRevenue;

    public double userTax;
    public double userAfterTax;

    public Menu(double userRevenue, double userTax, double userAfterTax) {
        this.userAfterTax = userAfterTax;
        this.userTax = userTax;
        this.userRevenue = userRevenue;
    }

    public void setUserRevenue() {
        userRevenue = this.userRevenue;
    }
    public double getUserRevenue() {
        return userRevenue;
    }
    public void setUserAfterTax() {
        userAfterTax = this.userAfterTax;
    }
    public double getUserAfterTax() {
        return userAfterTax;
    }
    public double getUserTax() {
        return userTax;
    }

    public void setUserTax(double userTax) {
        this.userTax = userTax;
    }

}
