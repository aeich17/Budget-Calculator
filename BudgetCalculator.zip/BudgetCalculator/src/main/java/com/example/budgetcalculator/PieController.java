/** Group Members: Ej Boakye, Adam Eichman, Michel Emborsky, Jake Ferner, Hunter Uebelacker
 * Date: 11/27/2022
 * Section: CSC 331
 * Purpose: PieController is the controller for the Pie.fxml scene.
 * The scene includes a button that takes the user back to the BudgetCalculatorHome.fxml scene
 * so the user can redo their budget. */


package com.example.budgetcalculator;

import javafx.fxml.FXML;
import javafx.scene.control.Button;


public class PieController {

    @FXML
    private Button Business;


}

